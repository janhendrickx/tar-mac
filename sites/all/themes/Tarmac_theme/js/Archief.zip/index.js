(function ($) {
    $('document').ready(function() {
        var options = { videoId: 'ANXGJe6i3G8', start: 3, mute: true };
        $('#wrapper').tubular(options);

    });
})(jQuery);


